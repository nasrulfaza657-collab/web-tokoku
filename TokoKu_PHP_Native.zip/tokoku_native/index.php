<?php
declare(strict_types=1);
session_start();
require __DIR__ . '/config.php';

function e($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function rupiah($value): string { return 'Rp ' . number_format((float)$value, 0, ',', '.'); }
function go(string $page): never { header('Location: index.php?page=' . urlencode($page)); exit; }
function flash(string $message, string $type='success'): void { $_SESSION['flash'] = [$message, $type]; }

$page = $_GET['page'] ?? 'dashboard';
$allowed = ['dashboard','pelanggan','transaksi','laporan','view','join','subquery','procedure','function','trigger','transaction','explain'];
if (!in_array($page, $allowed, true)) $page = 'dashboard';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'save_customer') {
            $id = (int)($_POST['id_pelanggan'] ?? 0);
            $nama = trim($_POST['nama_pelanggan'] ?? '');
            $kota = trim($_POST['kota'] ?? '');
            if ($nama === '') throw new RuntimeException('Nama pelanggan wajib diisi.');
            if ($id > 0) {
                $st = $pdo->prepare('UPDATE tbl_pelanggan SET nama_pelanggan=?, kota=? WHERE id_pelanggan=?');
                $st->execute([$nama, $kota, $id]);
                flash('Data pelanggan berhasil diperbarui.');
            } else {
                $st = $pdo->prepare('INSERT INTO tbl_pelanggan (nama_pelanggan,kota) VALUES (?,?)');
                $st->execute([$nama, $kota]);
                flash('Pelanggan baru berhasil ditambahkan.');
            }
            go('pelanggan');
        }
        if ($action === 'delete_customer') {
            $id = (int)$_POST['id_pelanggan'];
            $st = $pdo->prepare('SELECT COUNT(*) FROM tbl_transaksi WHERE id_pelanggan=?');
            $st->execute([$id]);
            if ((int)$st->fetchColumn() > 0) throw new RuntimeException('Pelanggan memiliki transaksi. Hapus/transaksikan datanya terlebih dahulu.');
            $st = $pdo->prepare('DELETE FROM tbl_pelanggan WHERE id_pelanggan=?');
            $st->execute([$id]);
            flash('Pelanggan berhasil dihapus.');
            go('pelanggan');
        }
        if ($action === 'save_transaction') {
            $id = (int)$_POST['id_pelanggan'];
            $tanggal = $_POST['tanggal'] ?: date('Y-m-d');
            $total = (float)$_POST['total_belanja'];
            if ($total < 0) throw new RuntimeException('Total belanja tidak boleh negatif.');
            $st = $pdo->prepare('INSERT INTO tbl_transaksi (tanggal,id_pelanggan,total_belanja) VALUES (?,?,?)');
            $st->execute([$tanggal, $id, $total]);
            flash('Transaksi berhasil disimpan.');
            go('transaksi');
        }
        if ($action === 'call_procedure') {
            $proc = $_POST['procedure'] ?? '';
            if ($proc === 'TampilPelanggan') {
                $call = $pdo->query('CALL TampilPelanggan()'); $call->fetchAll(); while($call->nextRowset()){}
                $_SESSION['proc_result'] = $pdo->query('SELECT * FROM tbl_pelanggan ORDER BY id_pelanggan DESC')->fetchAll();
            } elseif ($proc === 'CariPelanggan') {
                $st=$pdo->prepare('CALL CariPelanggan(?)'); $st->execute([(int)$_POST['param_id']]);
                $_SESSION['proc_result']=$st->fetchAll(); while($st->nextRowset()){}
            } elseif ($proc === 'TambahPelanggan') {
                $st=$pdo->prepare('CALL TambahPelanggan(?,?)'); $st->execute([trim($_POST['param_nama']),trim($_POST['param_kota'])]);
                while($st->nextRowset()){} $_SESSION['proc_result']=[['hasil'=>'Pelanggan berhasil ditambahkan melalui Stored Procedure.']];
            } elseif ($proc === 'LaporanTransaksi') {
                $st=$pdo->prepare('CALL LaporanTransaksi(?)'); $st->execute([(int)$_POST['param_id']]);
                $_SESSION['proc_result']=$st->fetchAll(); while($st->nextRowset()){}
            } elseif ($proc === 'HitungPelanggan') {
                $call=$pdo->query('CALL HitungPelanggan(@jumlah)'); while($call->nextRowset()){} $_SESSION['proc_result']=[['jumlah_pelanggan'=>$pdo->query('SELECT @jumlah')->fetchColumn()]];
            } else throw new RuntimeException('Stored Procedure tidak dikenal.');
            flash('Stored Procedure berhasil dipanggil.');
            go('procedure');
        }
        if ($action === 'test_transaction') {
            $mode = $_POST['mode'] ?? 'rollback';
            $pdo->beginTransaction();
            $customer = (int)$pdo->query('SELECT id_pelanggan FROM tbl_pelanggan ORDER BY id_pelanggan LIMIT 1')->fetchColumn();
            if (!$customer) throw new RuntimeException('Tambahkan minimal satu pelanggan untuk menguji transaksi.');
            $st=$pdo->prepare('INSERT INTO tbl_transaksi (tanggal,id_pelanggan,total_belanja) VALUES (?,?,?)');
            $st->execute([date('Y-m-d'),$customer,12345]);
            if ($mode === 'commit') {
                $pdo->commit();
                flash('COMMIT berhasil. Data uji tersimpan di tabel transaksi.');
            } else {
                $pdo->rollBack();
                flash('ROLLBACK berhasil. Data uji dibatalkan dan tidak tersimpan.');
            }
            go('transaction');
        }
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash($ex->getMessage(), 'error');
        go($page);
    }
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$search = trim($_GET['q'] ?? '');
$customers = $pdo->query('SELECT * FROM tbl_pelanggan ORDER BY id_pelanggan DESC')->fetchAll();
$stats = [
    'customers' => (int)$pdo->query('SELECT COUNT(*) FROM tbl_pelanggan')->fetchColumn(),
    'transactions' => (int)$pdo->query('SELECT COUNT(*) FROM tbl_transaksi')->fetchColumn(),
    'revenue' => (float)$pdo->query('SELECT COALESCE(SUM(total_belanja),0) FROM tbl_transaksi')->fetchColumn(),
    'cities' => (int)$pdo->query('SELECT COUNT(DISTINCT kota) FROM tbl_pelanggan')->fetchColumn(),
];

$titleMap = [
'dashboard'=>'Dashboard','pelanggan'=>'Data Pelanggan','transaksi'=>'Data Transaksi','laporan'=>'Laporan Toko',
'view'=>'Pengujian VIEW','join'=>'Pengujian JOIN','subquery'=>'Pengujian Subquery','procedure'=>'Stored Procedure',
'function'=>'Pengujian Function','trigger'=>'Pengujian Trigger','transaction'=>'COMMIT & ROLLBACK','explain'=>'Analisis EXPLAIN'
];
$title = $titleMap[$page];

function rows(PDO $pdo, string $sql): array { return $pdo->query($sql)->fetchAll(); }
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($title)?> · TokoKu</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="app-shell">
<aside class="sidebar" id="sidebar">
  <a class="brand" href="index.php"><span class="brand-mark">✦</span><span><b>TokoKu</b><small>ADMIN PANEL</small></span></a>
  <div class="side-label">MENU UTAMA</div>
  <nav>
    <a class="<?= $page==='dashboard'?'active':'' ?>" href="?page=dashboard"><i>⌂</i>Dashboard</a>
    <a class="<?= $page==='pelanggan'?'active':'' ?>" href="?page=pelanggan"><i>♙</i>Pelanggan</a>
    <a class="<?= $page==='transaksi'?'active':'' ?>" href="?page=transaksi"><i>▤</i>Transaksi</a>
    <a class="<?= in_array($page,['laporan','view','join','subquery'])?'active':'' ?>" href="?page=laporan"><i>▥</i>Laporan</a>
  </nav>
  <div class="side-label">PENGUJIAN DATABASE</div>
  <nav>
    <a class="<?= $page==='view'?'active':'' ?>" href="?page=view"><i>◉</i>1. View</a>
    <a class="<?= $page==='join'?'active':'' ?>" href="?page=join"><i>⌁</i>2. JOIN</a>
    <a class="<?= $page==='subquery'?'active':'' ?>" href="?page=subquery"><i>⌕</i>3. Subquery</a>
    <a class="<?= $page==='procedure'?'active':'' ?>" href="?page=procedure"><i>▶</i>4. Stored Procedure</a>
    <a class="<?= $page==='function'?'active':'' ?>" href="?page=function"><i>ƒx</i>5. Function</a>
    <a class="<?= $page==='trigger'?'active':'' ?>" href="?page=trigger"><i>ϟ</i>6. Trigger</a>
    <a class="<?= $page==='transaction'?'active':'' ?>" href="?page=transaction"><i>⟳</i>7. COMMIT & ROLLBACK</a>
    <a class="<?= $page==='explain'?'active':'' ?>" href="?page=explain"><i>▥</i>8. EXPLAIN</a>
  </nav>
  <div class="sidebar-bottom"><div class="rocket">🚀</div><b>TokoKu Database</b><small>Kelola dan uji data tokomu.</small><span>PHP Native · MySQL</span></div>
</aside>
<main class="main">
<header class="topbar">
  <button class="mobile-menu" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button>
  <div class="searchbox">⌕ <form method="get"><input name="q" value="<?=e($search)?>" placeholder="Cari pelanggan atau transaksi..."><input type="hidden" name="page" value="<?=$page?>"></form></div>
  <div class="top-actions"><span class="status-dot"></span><span>Database terhubung</span><div class="avatar">A</div><b>Admin</b></div>
</header>
<section class="content">
<div class="page-heading"><div><div class="eyebrow">TOKOKU / ADMIN</div><h1><?=e($title)?></h1><p><?= $page==='dashboard'?'Pantau aktivitas dan performa tokomu hari ini.':'Kelola data dan jalankan pengujian database db_tokoku.' ?></p></div><div class="date-chip">◷ <?=date('d M Y')?></div></div>
<?php if($flash): ?><div class="alert <?=$flash[1]==='error'?'danger':'success'?>"><?=e($flash[0])?></div><?php endif; ?>

<?php if($page==='dashboard'): ?>
<div class="stats-grid">
 <div class="stat-card blue"><div class="stat-icon">♙</div><span>Total Pelanggan</span><strong><?=$stats['customers']?></strong><small>Data pelanggan terdaftar</small><div class="spark">⌁</div></div>
 <div class="stat-card green"><div class="stat-icon">▤</div><span>Total Transaksi</span><strong><?=$stats['transactions']?></strong><small>Seluruh transaksi tercatat</small><div class="spark">⌁</div></div>
 <div class="stat-card orange"><div class="stat-icon">◈</div><span>Total Pendapatan</span><strong><?=rupiah($stats['revenue'])?></strong><small>Akumulasi total belanja</small><div class="spark">⌁</div></div>
 <div class="stat-card purple"><div class="stat-icon">⌖</div><span>Kota Pelanggan</span><strong><?=$stats['cities']?></strong><small>Kota berbeda</small><div class="spark">⌁</div></div>
</div>
<div class="dashboard-grid">
 <div class="panel chart-panel"><div class="panel-head"><div><h3>Ringkasan Transaksi</h3><p>Jumlah transaksi berdasarkan tanggal</p></div><span class="tag">LIVE DATA</span></div><canvas id="salesChart" height="110"></canvas></div>
 <div class="panel"><div class="panel-head"><div><h3>Pengujian Akhir</h3><p>8 materi pengujian database</p></div><span class="mini-icon">✦</span></div>
 <div class="test-shortcuts">
 <?php foreach([['view','View','Lihat laporan'],['join','JOIN','Gabungkan tabel'],['subquery','Subquery','Analisis data'],['procedure','Stored Procedure','Panggil prosedur'],['function','Function','Hitung nilai'],['trigger','Trigger','Otomatis berjalan'],['transaction','COMMIT & ROLLBACK','Uji transaksi'],['explain','EXPLAIN','Analisis query']] as $i=>$x): ?>
 <a href="?page=<?=$x[0]?>" class="test-link"><span><?=sprintf('%02d',$i+1)?></span><div><b><?=$x[1]?></b><small><?=$x[2]?></small></div><i>↗</i></a>
 <?php endforeach ?>
 </div></div>
</div>
<div class="panel table-panel"><div class="panel-head"><div><h3>Transaksi Terbaru</h3><p>Data transaksi terakhir dari database</p></div><a class="text-link" href="?page=transaksi">Lihat semua ↗</a></div>
<?php $recent=rows($pdo,"SELECT t.id_transaksi,t.tanggal,p.nama_pelanggan,t.total_belanja FROM tbl_transaksi t LEFT JOIN tbl_pelanggan p ON p.id_pelanggan=t.id_pelanggan ORDER BY t.id_transaksi DESC LIMIT 5"); ?>
<?php renderTable($recent,['id_transaksi'=>'ID','nama_pelanggan'=>'Pelanggan','tanggal'=>'Tanggal','total_belanja'=>'Total'], 'money'); ?>
</div>
<?php elseif($page==='pelanggan'): ?>
<div class="panel form-panel"><div class="panel-head"><div><h3>Tambah Pelanggan</h3><p>Masukkan informasi pelanggan baru</p></div></div>
<form method="post" class="inline-form"><input type="hidden" name="action" value="save_customer"><input name="nama_pelanggan" placeholder="Nama pelanggan" required><input name="kota" placeholder="Kota"><button class="btn primary">＋ Tambah Pelanggan</button></form></div>
<div class="panel table-panel"><div class="panel-head"><div><h3>Daftar Pelanggan</h3><p><?=$stats['customers']?> pelanggan tersimpan</p></div></div>
<?php $list=$pdo->prepare("SELECT * FROM tbl_pelanggan WHERE nama_pelanggan LIKE ? OR kota LIKE ? ORDER BY id_pelanggan DESC");$list->execute(["%$search%","%$search%"]);$data=$list->fetchAll(); ?>
<table><thead><tr><th>ID</th><th>Nama Pelanggan</th><th>Kota</th><th>Aksi</th></tr></thead><tbody>
<?php foreach($data as $r): ?><tr><td>#<?=$r['id_pelanggan']?></td><td><b><?=e($r['nama_pelanggan'])?></b></td><td><?=e($r['kota'])?></td><td class="actions">
<button class="btn tiny" onclick='editCustomer(<?=json_encode($r,JSON_HEX_APOS|JSON_HEX_QUOT)?>)'>Edit</button>
<form method="post" onsubmit="return confirm('Yakin menghapus pelanggan ini?')"><input type="hidden" name="action" value="delete_customer"><input type="hidden" name="id_pelanggan" value="<?=$r['id_pelanggan']?>"><button class="btn tiny danger-btn">Hapus</button></form></td></tr><?php endforeach ?>
<?php if(!$data): ?><tr><td colspan="4" class="empty">Belum ada data pelanggan.</td></tr><?php endif ?></tbody></table></div>
<div class="modal" id="editModal"><form method="post" class="modal-card"><button type="button" class="modal-close" onclick="closeEdit()">×</button><h3>Edit Pelanggan</h3><input type="hidden" name="action" value="save_customer"><input type="hidden" name="id_pelanggan" id="editId"><label>Nama</label><input name="nama_pelanggan" id="editNama" required><label>Kota</label><input name="kota" id="editKota"><button class="btn primary">Simpan Perubahan</button></form></div>
<?php elseif($page==='transaksi'): ?>
<div class="panel form-panel"><div class="panel-head"><div><h3>Tambah Transaksi</h3><p>Catat transaksi pelanggan</p></div></div><form method="post" class="inline-form"><input type="hidden" name="action" value="save_transaction"><select name="id_pelanggan" required><option value="">Pilih pelanggan</option><?php foreach($customers as $c): ?><option value="<?=$c['id_pelanggan']?>"><?=e($c['nama_pelanggan'])?></option><?php endforeach ?></select><input type="date" name="tanggal" value="<?=date('Y-m-d')?>"><input type="number" name="total_belanja" min="0" step="0.01" placeholder="Total belanja" required><button class="btn primary">＋ Simpan Transaksi</button></form></div>
<div class="panel table-panel"><div class="panel-head"><div><h3>Riwayat Transaksi</h3><p>Transaksi dan pelanggan digabungkan dengan JOIN</p></div></div>
<?php $st=$pdo->prepare("SELECT t.id_transaksi,t.tanggal,p.nama_pelanggan,p.kota,t.total_belanja FROM tbl_transaksi t LEFT JOIN tbl_pelanggan p ON t.id_pelanggan=p.id_pelanggan WHERE p.nama_pelanggan LIKE ? ORDER BY t.id_transaksi DESC");$st->execute(["%$search%"]);renderTable($st->fetchAll(),['id_transaksi'=>'ID','tanggal'=>'Tanggal','nama_pelanggan'=>'Pelanggan','kota'=>'Kota','total_belanja'=>'Total'],'money'); ?></div>
<?php elseif($page==='laporan' || $page==='view'): ?>
<div class="info-banner"><b>VIEW Database</b><span>Data berikut diambil langsung dari view yang sudah tersedia pada db_tokoku.</span></div>
<div class="panel table-panel"><div class="panel-head"><div><h3>view_pelanggan</h3><p>Daftar pelanggan melalui VIEW</p></div></div><?php renderTable(rows($pdo,'SELECT * FROM view_pelanggan'),['id_pelanggan'=>'ID','nama_pelanggan'=>'Nama','kota'=>'Kota']); ?></div>
<div class="panel table-panel"><div class="panel-head"><div><h3>view_total_belanja</h3><p>Rekap transaksi dan total belanja per pelanggan</p></div></div><?php renderTable(rows($pdo,'SELECT * FROM view_total_belanja'),['id_pelanggan'=>'ID','nama_pelanggan'=>'Pelanggan','total_transaksi'=>'Jumlah Transaksi','total_belanja'=>'Total Belanja'],'money'); ?></div>
<div class="panel table-panel"><div class="panel-head"><div><h3>view_transaksi_pelanggan</h3><p>Detail transaksi melalui VIEW</p></div></div><?php renderTable(rows($pdo,'SELECT * FROM view_transaksi_pelanggan ORDER BY tanggal DESC'),['id_transaksi'=>'ID','tanggal'=>'Tanggal','nama_pelanggan'=>'Pelanggan','kota'=>'Kota','total_belanja'=>'Total'],'money'); ?></div>
<?php elseif($page==='join'): ?>
<div class="info-banner"><b>JOIN: tbl_transaksi + tbl_pelanggan</b><span>Menggabungkan data transaksi dengan informasi pemilik transaksi.</span></div>
<div class="panel table-panel"><?php $data=rows($pdo,'SELECT t.id_transaksi,t.tanggal,p.nama_pelanggan,p.kota,t.total_belanja FROM tbl_transaksi t INNER JOIN tbl_pelanggan p ON t.id_pelanggan=p.id_pelanggan ORDER BY t.id_transaksi DESC');renderTable($data,['id_transaksi'=>'ID Transaksi','tanggal'=>'Tanggal','nama_pelanggan'=>'Nama Pelanggan','kota'=>'Kota','total_belanja'=>'Total'],'money'); ?></div>
<?php elseif($page==='subquery'): ?>
<div class="info-banner"><b>Analisis menggunakan Subquery</b><span>Menampilkan pelanggan yang total belanjanya di atas rata-rata seluruh transaksi per pelanggan.</span></div>
<div class="panel table-panel"><?php $data=rows($pdo,"SELECT p.id_pelanggan,p.nama_pelanggan,p.kota,(SELECT COALESCE(SUM(t.total_belanja),0) FROM tbl_transaksi t WHERE t.id_pelanggan=p.id_pelanggan) AS total_belanja FROM tbl_pelanggan p WHERE (SELECT COALESCE(SUM(t.total_belanja),0) FROM tbl_transaksi t WHERE t.id_pelanggan=p.id_pelanggan) > (SELECT AVG(x.total_per_pelanggan) FROM (SELECT SUM(total_belanja) total_per_pelanggan FROM tbl_transaksi GROUP BY id_pelanggan) x) ORDER BY total_belanja DESC");renderTable($data,['id_pelanggan'=>'ID','nama_pelanggan'=>'Pelanggan','kota'=>'Kota','total_belanja'=>'Total Belanja'],'money'); ?></div>
<?php elseif($page==='procedure'): ?>
<div class="info-banner"><b>Stored Procedure</b><span>Pilih prosedur yang ingin dijalankan. Semua nama sesuai database db_tokoku.</span></div>
<div class="panel form-panel"><form method="post" class="procedure-form"><input type="hidden" name="action" value="call_procedure"><label>Stored Procedure</label><select name="procedure" id="procedureSelect" onchange="procedureFields()"><option>TampilPelanggan</option><option>CariPelanggan</option><option>HitungPelanggan</option><option>LaporanTransaksi</option><option>TambahPelanggan</option></select><div id="procId" class="field-hidden"><label>ID Pelanggan</label><input type="number" name="param_id" value="1"></div><div id="procAdd" class="field-hidden"><label>Nama Pelanggan</label><input name="param_nama" placeholder="Nama"><label>Kota</label><input name="param_kota" placeholder="Kota"></div><button class="btn primary">▶ Jalankan Procedure</button></form></div>
<?php if(isset($_SESSION['proc_result'])): $res=$_SESSION['proc_result'];unset($_SESSION['proc_result']); ?><div class="panel table-panel"><div class="panel-head"><h3>Hasil Stored Procedure</h3></div><?php renderTable($res); ?></div><?php endif ?>
<div class="panel code-panel"><b>Daftar prosedur tersedia</b><code> TampilPelanggan() · CariPelanggan(IN p_id) · HitungPelanggan(OUT jumlah) · LaporanTransaksi(IN p_id_pelanggan) · TambahPelanggan(IN p_nama, IN p_kota)</code></div>
<?php elseif($page==='function'): ?>
<div class="info-banner"><b>Pengujian Function</b><span>Hasil dihitung langsung oleh function yang tersimpan di MySQL.</span></div>
<div class="panel form-panel"><form method="get" class="function-grid"><input type="hidden" name="page" value="function"><div><label>Harga / Total</label><input type="number" step="0.01" name="harga" value="<?=e($_GET['harga']??100000)?>"></div><div><label>Diskon (%)</label><input type="number" step="0.01" name="diskon" value="<?=e($_GET['diskon']??10)?>"></div><div><label>Jumlah</label><input type="number" name="jumlah" value="<?=e($_GET['jumlah']??2)?>"></div><div><label>Nilai</label><input type="number" name="nilai" value="<?=e($_GET['nilai']??85)?>"></div><button class="btn primary">Hitung Function</button></form></div>
<?php if(isset($_GET['harga'])): $h=(float)$_GET['harga'];$d=(float)$_GET['diskon'];$j=(int)$_GET['jumlah'];$n=(int)$_GET['nilai'];$st=$pdo->prepare('SELECT HitungDiskon(?,?) diskon, HitungPajak(?) pajak, HitungTotal(?,?) total, KategoriBelanja(?) kategori, KonversiNilai(?) konversi');$st->execute([$h,$d,$h,$h,$j,$h,$n]);$r=$st->fetch(); ?><div class="result-grid"><?php foreach($r as $k=>$v): ?><div class="result-card"><small><?=e(ucwords(str_replace('_',' ',$k)))?></small><b><?=e(is_numeric($v)?rupiah($v):$v)?></b></div><?php endforeach ?></div><?php endif ?>
<div class="panel code-panel"><b>Function tersedia</b><code>HitungDiskon · HitungPajak · HitungTotal · KategoriBelanja · KonversiNilai</code></div>
<?php elseif($page==='trigger'): ?>
<div class="info-banner"><b>Pengujian Trigger Otomatis</b><span>Tambah atau ubah pelanggan untuk memicu trigger. Hasilnya dicatat ke tabel log.</span></div>
<div class="panel form-panel"><h3>Trigger yang tersedia</h3><div class="trigger-list"><div><b>after_insert_pelanggan</b><small>Setelah pelanggan ditambahkan, mencatat aktivitas ke log_pelanggan.</small></div><div><b>after_update_pelanggan</b><small>Mencatat nama lama dan nama baru ke log_perubahan_pelanggan.</small></div><div><b>before_insert_transaksi</b><small>Menolak total belanja bernilai negatif.</small></div></div><a class="btn primary" href="?page=pelanggan">＋ Uji tambah / edit pelanggan</a></div>
<div class="panel table-panel"><div class="panel-head"><h3>Log Insert Pelanggan</h3></div><?php renderTable(rows($pdo,'SELECT * FROM log_pelanggan ORDER BY waktu DESC'),['id_log'=>'ID','aktivitas'=>'Aktivitas','id_pelanggan'=>'ID Pelanggan','waktu'=>'Waktu']); ?></div>
<div class="panel table-panel"><div class="panel-head"><h3>Log Perubahan Pelanggan</h3></div><?php renderTable(rows($pdo,'SELECT * FROM log_perubahan_pelanggan ORDER BY waktu DESC'),['id_log'=>'ID','id_pelanggan'=>'ID Pelanggan','nama_lama'=>'Nama Lama','nama_baru'=>'Nama Baru','waktu'=>'Waktu']); ?></div>
<?php elseif($page==='transaction'): ?>
<div class="info-banner"><b>Uji transaksi database</b><span>Gunakan data uji Rp12.345 untuk melihat perbedaan COMMIT dan ROLLBACK. Pastikan tabel menggunakan InnoDB.</span></div>
<div class="transaction-cards"><div class="panel"><div class="big-symbol green-text">✓</div><h3>COMMIT</h3><p>Menyimpan perubahan transaksi secara permanen.</p><form method="post"><input type="hidden" name="action" value="test_transaction"><input type="hidden" name="mode" value="commit"><button class="btn primary">Jalankan COMMIT</button></form></div><div class="panel"><div class="big-symbol red-text">↶</div><h3>ROLLBACK</h3><p>Membatalkan perubahan sehingga data uji tidak tersimpan.</p><form method="post"><input type="hidden" name="action" value="test_transaction"><input type="hidden" name="mode" value="rollback"><button class="btn danger-btn">Jalankan ROLLBACK</button></form></div></div>
<div class="panel table-panel"><div class="panel-head"><h3>Transaksi terbaru</h3></div><?php renderTable(rows($pdo,'SELECT t.id_transaksi,t.tanggal,p.nama_pelanggan,t.total_belanja FROM tbl_transaksi t LEFT JOIN tbl_pelanggan p ON p.id_pelanggan=t.id_pelanggan ORDER BY t.id_transaksi DESC LIMIT 8'),['id_transaksi'=>'ID','tanggal'=>'Tanggal','nama_pelanggan'=>'Pelanggan','total_belanja'=>'Total'],'money'); ?></div>
<?php elseif($page==='explain'): ?>
<div class="info-banner"><b>EXPLAIN Query</b><span>Melihat cara MySQL menjalankan query, termasuk type, key, dan perkiraan jumlah baris.</span></div>
<div class="panel code-panel"><b>Query yang dianalisis</b><code>SELECT t.id_transaksi, p.nama_pelanggan, t.total_belanja FROM tbl_transaksi t JOIN tbl_pelanggan p ON t.id_pelanggan=p.id_pelanggan WHERE p.kota='Ponorogo';</code></div>
<div class="panel table-panel"><?php $data=rows($pdo,"EXPLAIN SELECT t.id_transaksi,p.nama_pelanggan,t.total_belanja FROM tbl_transaksi t JOIN tbl_pelanggan p ON t.id_pelanggan=p.id_pelanggan WHERE p.kota='Ponorogo'");renderTable($data); ?></div>
<div class="hint">Perhatikan kolom <b>type</b>, <b>possible_keys</b>, <b>key</b>, dan <b>rows</b>. Nilainya bergantung pada jumlah data dan index di database.</div>
<?php endif; ?>
<footer>© <?=date('Y')?> TokoKu Admin Panel <span>PHP Native · MySQL · Dibuat untuk Pengujian Basis Data</span></footer>
</section>
</main></div>
<script>
function editCustomer(row){document.getElementById('editId').value=row.id_pelanggan;document.getElementById('editNama').value=row.nama_pelanggan||'';document.getElementById('editKota').value=row.kota||'';document.getElementById('editModal').classList.add('show')}
function closeEdit(){document.getElementById('editModal').classList.remove('show')}
function procedureFields(){let p=document.getElementById('procedureSelect')?.value;document.getElementById('procId')?.classList.toggle('field-hidden',!['CariPelanggan','LaporanTransaksi'].includes(p));document.getElementById('procAdd')?.classList.toggle('field-hidden',p!=='TambahPelanggan')}
<?php if($page==='procedure'): ?>procedureFields();<?php endif ?>
<?php if($page==='dashboard'): ?>
<?php $chart=rows($pdo,"SELECT DATE_FORMAT(tanggal,'%d %b') label,COUNT(*) jumlah FROM tbl_transaksi GROUP BY tanggal ORDER BY tanggal"); ?>
new Chart(document.getElementById('salesChart'),{type:'line',data:{labels:<?=json_encode(array_column($chart,'label'))?>,datasets:[{label:'Transaksi',data:<?=json_encode(array_map('intval',array_column($chart,'jumlah')))?>,borderColor:'#8b5cf6',backgroundColor:'rgba(139,92,246,.14)',fill:true,tension:.42,pointRadius:4,pointBackgroundColor:'#a78bfa'}]},options:{plugins:{legend:{display:false}},scales:{x:{grid:{color:'rgba(148,163,184,.08)'},ticks:{color:'#9caac5'}},y:{beginAtZero:true,grid:{color:'rgba(148,163,184,.08)'},ticks:{color:'#9caac5',precision:0}}}}});
<?php endif ?>
</script>
</body></html>
<?php
function renderTable(array $data, array $labels=[], string $moneyKey=''): void {
    if (!$labels && isset($data[0])) $labels=array_combine(array_keys($data[0]),array_keys($data[0]));
    echo '<div class="table-wrap"><table><thead><tr>';
    foreach($labels as $key=>$label) echo '<th>'.e($label).'</th>';
    echo '</tr></thead><tbody>';
    if(!$data){echo '<tr><td colspan="'.max(1,count($labels)).'" class="empty">Tidak ada data untuk ditampilkan.</td></tr>';}
    foreach($data as $row){echo '<tr>';foreach($labels as $key=>$label){$v=$row[$key]??'';if($key===$moneyKey || (str_contains(strtolower($key),'total') && is_numeric($v)))$v=rupiah($v);echo '<td>'.e($v).'</td>';}echo '</tr>';}
    echo '</tbody></table></div>';
}
?>
